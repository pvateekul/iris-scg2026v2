---
name: internal-comms
description: Writes concise internal updates for QA, production, and management teams, including 3P updates and short project status summaries.
---

# Internal Comms

This skill helps write short internal communication updates for food process quality work.

## When to Use This Skill

Use this skill when the task involves:

- Writing a 3P update
- Writing a short QA status update
- Summarizing progress for managers
- Updating production and QA teams
- Communicating current issues, next steps, and blockers

## 3P Format

Use the 3P format:

1. **Progress**
   - What has been completed or found

2. **Plans**
   - What will happen next

3. **Problems**
   - What is blocked, unclear, or risky

## Typical Inputs

This skill may use:

- `assets/final_quality_review.md`
- `assets/deviation_pattern_summary.md`
- `assets/corrective_action_plan.md`
- `references/brand_voice.md`

## Workflow

1. Identify the audience.
2. Identify the time period.
3. Extract the most important progress, plans, and problems.
4. Keep the update concise.
5. Use operational language.
6. Avoid unnecessary detail.
7. Include blockers or missing information clearly.

## Output Requirements

Use this exact format:

```md
# Internal 3P Update

[Emoji] [Team or Project Name] ([Date or Period])

Progress: [1–3 concise sentences]

Plans: [1–3 concise sentences]

Problems: [1–3 concise sentences]
```

## Style Guidelines

- Concise
- Practical
- Calm
- Direct
- Suitable for QA, production, and management readers

## Guardrails

- Do not include unsupported claims.
- Do not overstate certainty.
- Do not blame teams or individuals.
- Keep it readable in under one minute.

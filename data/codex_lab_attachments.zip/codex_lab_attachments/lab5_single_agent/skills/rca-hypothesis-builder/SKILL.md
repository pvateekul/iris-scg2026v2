---
name: rca-hypothesis-builder
description: Builds evidence-based RCA hypotheses for food process issues without overclaiming the true root cause.
---

# RCA Hypothesis Builder

This skill helps turn observed food process issue patterns into possible root cause hypotheses.

The goal is not to prove the true root cause. The goal is to structure RCA thinking and identify what evidence is available, what is missing, and what should be checked next.

## When to Use This Skill

Use this skill when the task involves:

- Root cause analysis support
- Food process deviation review
- Explaining possible contributing factors
- Mapping issues to RCA categories
- Preparing investigation hypotheses
- Separating evidence from assumptions

## RCA Categories

Use these categories when useful:

- People
- Process
- Equipment
- Material
- Measurement
- Environment
- Supplier
- Documentation / Recordkeeping

## Typical Inputs

This skill may use:

- `assets/deviation_pattern_summary.md`
- `data/food_deviation_log.csv`
- `references/rca_categories.md`
- `references/process_notes.md`
- `references/qa_guidelines.md`

## Workflow

1. Read the observed issue pattern.
2. Identify the affected product, line, shift, process step, and deviation type.
3. Generate possible contributing factors.
4. Map each factor to an RCA category.
5. Identify supporting evidence from the log or references.
6. Identify missing information.
7. Assign confidence level:
   - High: directly supported by repeated evidence
   - Medium: partially supported
   - Low: plausible but weakly supported
8. Recommend what should be checked next.

## Output Requirements

Create an RCA hypothesis table:

```md
# RCA Hypothesis Table

## Issue Pattern Reviewed

Briefly describe the observed pattern.

## Hypotheses

| Hypothesis | RCA Category | Supporting Evidence | Missing Information | Confidence | Follow-up Needed |
|---|---|---|---|---|---|

## Notes

- Do not treat these hypotheses as confirmed root causes.
- The true root cause requires confirmation from QA, production, or site investigation.
```

## Guardrails

- Do not claim the true root cause unless the evidence is explicit.
- Do not blame individuals or teams.
- Use neutral, operational language.
- Prefer "possible contributing factor" over "root cause" when evidence is incomplete.
- State uncertainty clearly.

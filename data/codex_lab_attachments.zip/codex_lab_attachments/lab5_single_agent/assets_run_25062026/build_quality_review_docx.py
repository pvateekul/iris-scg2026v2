from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "final_quality_review_with_visuals.docx"
PLOTS = ROOT / "assets" / "plots"
BLUE = RGBColor(47, 111, 115)
GREEN = RGBColor(66, 113, 82)
GOLD = RGBColor(137, 105, 41)
INK = RGBColor(31, 45, 54)
MUTED = RGBColor(90, 98, 105)
LIGHT = "F2F5F4"
HEADER = "DDE9E6"
WHITE = "FFFFFF"
BORDER = "B8C8C4"

def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)

def set_cell_margins(cell, top=90, start=120, bottom=90, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for edge, value in {"top": top, "start": start, "bottom": bottom, "end": end}.items():
        node = tc_mar.find(qn(f"w:{edge}"))
        if node is None:
            node = OxmlElement(f"w:{edge}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")

def set_table_borders(table, color=BORDER):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ["top", "left", "bottom", "right", "insideH", "insideV"]:
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)

def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)

def set_width(cell, width):
    cell.width = Inches(width)
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.first_child_found_in("w:tcW")
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(int(width * 1440)))
    tc_w.set(qn("w:type"), "dxa")

def style_run(run, size=10.5, color=INK, bold=False, italic=False):
    run.font.name = "Calibri"
    run._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    run._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    run.font.size = Pt(size)
    run.font.color.rgb = color
    run.bold = bold
    run.italic = italic

def style_paragraph(paragraph, after=6, before=0, line=1.1):
    fmt = paragraph.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line

def add_text(doc, text, size=10.5, color=INK, bold=False, italic=False, after=6, before=0):
    paragraph = doc.add_paragraph()
    style_paragraph(paragraph, after=after, before=before)
    run = paragraph.add_run(text)
    style_run(run, size=size, color=color, bold=bold, italic=italic)
    return paragraph

def add_heading(doc, text, level=1):
    paragraph = doc.add_paragraph()
    paragraph.style = f"Heading {level}"
    run = paragraph.add_run(text)
    if level == 1:
        style_run(run, size=16, color=BLUE, bold=True)
        style_paragraph(paragraph, before=14, after=7)
    elif level == 2:
        style_run(run, size=13, color=BLUE, bold=True)
        style_paragraph(paragraph, before=10, after=5)
    else:
        style_run(run, size=11.5, color=GREEN, bold=True)
        style_paragraph(paragraph, before=8, after=4)
    return paragraph

def add_bullet(doc, text):
    paragraph = doc.add_paragraph(style="List Bullet")
    style_paragraph(paragraph, after=4)
    run = paragraph.add_run(text)
    style_run(run)

def add_numbered(doc, items):
    for item in items:
        paragraph = doc.add_paragraph(style="List Number")
        style_paragraph(paragraph, after=4)
        run = paragraph.add_run(item)
        style_run(run)

def add_table(doc, headers, rows, widths):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_borders(table)
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        set_width(cell, widths[index])
        set_cell_shading(cell, HEADER)
        set_cell_margins(cell)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        paragraph = cell.paragraphs[0]
        style_paragraph(paragraph, after=0)
        run = paragraph.add_run(header)
        style_run(run, size=9.2, color=INK, bold=True)
    set_repeat_table_header(table.rows[0])
    for row_index, row in enumerate(rows):
        cells = table.add_row().cells
        for index, value in enumerate(row):
            set_width(cells[index], widths[index])
            set_cell_shading(cells[index], WHITE if row_index % 2 == 0 else LIGHT)
            set_cell_margins(cells[index])
            cells[index].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            paragraph = cells[index].paragraphs[0]
            style_paragraph(paragraph, after=0)
            run = paragraph.add_run(value)
            style_run(run, size=8.7)
    doc.add_paragraph().paragraph_format.space_after = Pt(4)
    return table

def add_callout(doc, label, text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    set_table_borders(table, color="D6C28A")
    cell = table.cell(0, 0)
    set_cell_shading(cell, "FFF8E6")
    set_cell_margins(cell, top=140, bottom=140, start=160, end=160)
    paragraph = cell.paragraphs[0]
    style_paragraph(paragraph, after=0)
    label_run = paragraph.add_run(f"{label}: ")
    style_run(label_run, size=10.5, color=GOLD, bold=True)
    body_run = paragraph.add_run(text)
    style_run(body_run, size=10.5, color=INK)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)

def add_caption(doc, text):
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    style_paragraph(paragraph, after=8, before=2)
    run = paragraph.add_run(text)
    style_run(run, size=9, color=MUTED, italic=True)

def add_plot(doc, filename, caption):
    paragraph = doc.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = paragraph.add_run()
    run.add_picture(str(PLOTS / filename), width=Inches(5.8))
    add_caption(doc, caption)

def setup_styles(doc):
    section = doc.sections[0]
    section.top_margin = Inches(0.85)
    section.bottom_margin = Inches(0.85)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)
    section.header_distance = Inches(0.45)
    section.footer_distance = Inches(0.45)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = INK
    for name in ["Heading 1", "Heading 2", "Heading 3"]:
        doc.styles[name].font.name = "Calibri"
        doc.styles[name].font.bold = True
    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = header.add_run("Food Deviation Review | Workshop QA Package")
    style_run(run, size=8.5, color=MUTED)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run("Evidence-based review; RCA hypotheses are not confirmed root causes")
    style_run(run, size=8.5, color=MUTED)

def add_title_page(doc):
    add_text(doc, "Food Process Quality Review Report", size=24, color=INK, bold=True, after=4, before=18)
    add_text(doc, "Deviation review with visual evidence", size=14, color=MUTED, after=14)
    meta = [
        ["Date range", "2026-05-01 to 2026-05-12"],
        ["Records reviewed", "12 deviation log records"],
        ["Source", "data/food_deviation_log.csv and local QA references"],
        ["Prepared for", "QA and production workshop review"],
    ]
    add_table(doc, ["Field", "Value"], meta, [1.6, 4.7])
    add_callout(
        doc,
        "Review principle",
        "This report supports QA investigation and should not be treated as final root cause confirmation unless evidence is explicit.",
    )

def build_doc():
    doc = Document()
    setup_styles(doc)
    add_title_page(doc)
    add_heading(doc, "Executive Summary")
    add_text(doc, "The deviation log shows three practical review priorities: repeated cooling issues for Chilled chicken meal on Line 1, label and allergen verification weaknesses on Lines 1 and 2, and repeated metal detector rejects for Vegetable curry on Line 3.")
    add_text(doc, "The strongest immediate need is to confirm containment, release decisions, measured evidence, and closure documentation for open High and Medium severity records.")
    add_callout(doc, "Evidence boundary", "The evidence supports RCA hypotheses, not confirmed root causes. Missing measured values, batch IDs, quantities affected, due dates, and verification records limit final conclusions.")

    add_heading(doc, "Main Findings")
    add_table(doc, ["Finding", "Evidence", "Risk / Impact", "Priority"], [
        ["Repeated cooling-related deviations on Line 1", "4 Chilled chicken meal cooling records; 3 High severity cooling delays and 1 Medium severity incomplete cooling record", "Potential chilled-product process control and documentation risk", "High"],
        ["Label and allergen control issues", "2 Tomato sauce label mix-ups and 2 Beef rice bowl missing allergen checks", "Legal label, shelf-life, and allergen verification risk", "High"],
        ["Repeated Line 3 metal detector rejects", "3 Vegetable curry metal detector reject records, all Medium severity", "Equipment setting, product effect, reject mechanism, or foreign material control question", "Medium"],
        ["Open action load", "8 of 12 records are Open", "Closure evidence and ownership follow-up risk", "High"],
    ], [1.75, 2.2, 1.75, 0.65])

    add_heading(doc, "Visual Evidence")
    add_plot(doc, "deviations_by_process_step.png", "Figure 1. Deviations by process step.")
    add_plot(doc, "deviations_by_deviation_type.png", "Figure 2. Deviations by deviation type.")
    doc.add_section(WD_SECTION.NEW_PAGE)
    add_heading(doc, "Visual Evidence Continued")
    add_plot(doc, "open_deviations_by_owner.png", "Figure 3. Open deviations by owner.")
    add_plot(doc, "deviations_by_severity_status.png", "Figure 4. Deviations by severity and status.")

    add_heading(doc, "RCA Support Summary")
    add_table(doc, ["Issue Pattern", "Possible Contributing Factor", "Confidence", "Missing Information"], [
        ["Cooling delay / incomplete cooling record", "Cooling load, tray spacing, chiller performance, probe placement, or timestamp control", "Medium", "Batch size, cooling curves, target limits, chiller trend, probe calibration, release decision"],
        ["Label mix-up", "Label changeover or line clearance control weakness", "Medium", "Label reconciliation, obsolete label removal evidence, checklist completion, second-person verification"],
        ["Missing allergen check", "Handover or checklist completion weakness", "Medium", "Handover record, allergen checklist, release review, training status"],
        ["Metal detector rejects", "Product effect setting, detector sensitivity, reject mechanism setup, or equipment condition", "Medium", "Calibration, challenge test results, rejected-unit inspection, maintenance findings"],
        ["Open action management", "Due date and closure evidence gaps", "High", "Due dates, closure criteria, verification evidence"],
    ], [1.6, 2.25, 0.7, 1.75])

    add_heading(doc, "Recommended Follow-up")
    add_numbered(doc, [
        "Confirm containment, release status, measured evidence, and closure criteria for all High severity records.",
        "Review Line 1 cooling evidence for batch loading, tray spacing, chiller performance, and measurement reliability.",
        "Review Line 2 label changeover and Line 1 allergen verification controls, including line clearance and handover evidence.",
        "Review Line 3 metal detector calibration, sensitivity settings, challenge tests, reject mechanism checks, and product disposition.",
        "Add due dates and verification evidence requirements to all open actions.",
    ])

    add_heading(doc, "Corrective / Preventive Action Summary")
    add_table(doc, ["Action", "Owner", "Priority", "Evidence Needed"], [
        ["Confirm cooling hold, release decision, and temperature evidence for affected Chilled chicken meal records", "QA Supervisor", "High", "Cooling logs, batch hold records, QA disposition"],
        ["Confirm label reconciliation and allergen verification before release", "QA Supervisor / Packing Lead", "High", "Label reconciliation, allergen checklist, release review"],
        ["Review cooling load size, tray spacing, chiller performance, and probe placement", "Production Supervisor / QA Supervisor", "High", "Batch loading records, chiller checks, probe verification"],
        ["Review label changeover controls and obsolete label roll removal", "Packing Lead", "High", "Line clearance checklist, label roll reconciliation"],
        ["Review metal detector settings, challenge tests, reject mechanism, and maintenance notes", "Maintenance", "Medium", "Calibration record, sensitivity setting, reject inspection"],
        ["Add due dates, closure criteria, and verification evidence to open deviation tracking", "QA Supervisor", "High", "Updated tracker and reviewed open action list"],
    ], [2.35, 1.3, 0.65, 2.0])

    add_heading(doc, "Open Questions")
    for question in [
        "Were all affected batches or units held until QA release review was completed?",
        "What measured cooling values and target limits apply to the repeated cooling records?",
        "Were old label rolls fully removed and reconciled after Line 2 changeovers?",
        "What exactly caused the missing allergen verification during the Line 1 handover event?",
        "Were the Line 3 metal detector rejects caused by detector setup, product effect, reject mechanism, or actual rejected material?",
        "What evidence is required to close each currently open deviation?",
    ]:
        add_bullet(doc, question)

    add_heading(doc, "Final Notes")
    add_text(doc, "This integrated document combines the final quality review with the visual evidence created from the provided deviation log. It uses only the local project data and references.")
    add_text(doc, "The report is intended for workshop review by QA, production, packing, and maintenance teams.")
    doc.save(OUT)

if __name__ == "__main__":
    build_doc()
    print(OUT)

# RCA Hypothesis Table

## Issue Pattern Reviewed

The review covers 12 food process deviation records from 2026-05-01 to 2026-05-12. The main repeated patterns are cooling delays for Chilled chicken meal on Line 1, label and allergen control misses on Lines 1 and 2, and metal detector rejects for Vegetable curry on Line 3.

## Hypotheses
| Hypothesis | RCA Category | Supporting Evidence | Missing Information | Confidence | Follow-up Needed |
|---|---|---|---|---|---|
| Cooling capacity, loading, or tray spacing may be contributing to slower cooling on Line 1. | Process / Equipment / Environment | Three High severity cooling delay records for Chilled chicken meal on Line 1; one description notes a large batch load and slower temperature drop. | Batch sizes, tray spacing records, chiller loading records, room/chiller temperature trend, target cooling limits. | Medium | Compare affected batch loads and cooling curves against normal runs and acceptance criteria. |
| Cooling measurement and recordkeeping may be inconsistent. | Measurement / Documentation / Recordkeeping | One Medium severity incomplete cooling record; cooling end time was not recorded clearly. | Probe placement, calibration status, cooling log template, operator recording practice, review sign-off evidence. | Medium | Check cooling records for affected dates and verify probe placement and timestamp completion. |
| Label changeover controls may be weak during Line 2 Tomato sauce packing. | Process / Documentation / Recordkeeping | Two Medium severity label mix-ups on Line 2; one record notes an old label roll found after product changeover. | Line clearance checklist, label reconciliation count, printer template control, second-person verification evidence. | Medium | Review label changeover records and confirm whether old labels were fully removed and reconciled. |
| Allergen verification may be vulnerable during afternoon Line 1 labeling and handover. | People / Process / Documentation / Recordkeeping | Two High severity missing allergen check records for Beef rice bowl on Line 1; one description mentions shift handover. | Handover notes, allergen checklist design, release review evidence, training status, staffing or workload conditions. | Medium | Confirm the exact point where allergen verification was missed and whether release controls prevented shipment. |
| Metal detector rejects may relate to product effect settings, sensitivity, or reject mechanism setup for Vegetable curry. | Equipment / Process / Measurement | Three Medium severity metal detector reject records on Line 3; descriptions mention repeated rejects, product size adjustment, and repeated sensitivity check. | Detector calibration records, challenge test results, reject inspection records, product settings, maintenance findings. | Medium | Review detector settings, challenge tests, rejected unit inspection results, and maintenance notes for the affected dates. |
| Open action management may need tighter due date and closure evidence control. | Process / Documentation / Recordkeeping | 8 of 12 records remain Open; the log does not show due dates or verification evidence. | Due dates, completion status detail, closure criteria, responsible backup owner, escalation rules. | High | Add due dates and closure evidence requirements for open deviations. |

## Notes

- These hypotheses are not confirmed root causes.
- The true root cause requires confirmation from QA, production, maintenance, or site investigation.
- The log supports prioritizing investigation, but it does not include enough measured evidence to close RCA.

# Corrective Action Plan

## Summary

The action focus is on containing High severity cooling and allergen-control records, confirming the status of repeated metal detector rejects, and strengthening changeover, recordkeeping, and verification evidence for open deviations.

## Action Plan
| Action Type | Recommended Action | Owner | Priority | Evidence Needed | Notes |
|---|---|---|---|---|---|
| Containment | Confirm hold, release decision, and cooling evidence for all open Chilled chicken meal cooling records. | QA Supervisor | High | Cooling logs, batch hold records, QA disposition. | Do before closing any cooling-related record. |
| Containment | Confirm label and allergen verification before release for Beef rice bowl and Tomato sauce events. | QA Supervisor / Packing Lead | High | Label reconciliation, allergen checklist, release review. | Include any affected-unit checks. |
| Containment | Confirm Line 3 product disposition since the last good metal detector check. | QA Supervisor / Maintenance | Medium | Challenge test results, reject inspection, hold/release record. | Applies to repeated reject records. |
| Corrective Action | Review Line 1 cooling load size, tray spacing, chiller performance, and probe placement for affected dates. | Production Supervisor / QA Supervisor | High | Batch loading records, chiller checks, probe verification. | Evidence is partial; confirm before assigning cause. |
| Corrective Action | Review Line 2 label changeover procedure and remove access to obsolete label rolls at line level. | Packing Lead | High | Line clearance checklist, label roll reconciliation, corrected staging records. | Links to old label roll found after changeover. |
| Corrective Action | Review Line 3 metal detector settings, product effect setup, reject mechanism function, and maintenance findings. | Maintenance | Medium | Calibration record, sensitivity setting, reject mechanism test. | Required before confirming equipment contribution. |
| Preventive Action | Add mandatory cooling start/end timestamp completion check before QA release review. | QA Supervisor | High | Updated checklist, completed sample records. | Addresses incomplete cooling record gap. |
| Preventive Action | Add second-person verification for label changeover and allergen check completion on affected products. | Packing Lead / QA Supervisor | High | Revised checklist, training record, first-week verification records. | Keep the check practical for line use. |
| Preventive Action | Add due dates, closure criteria, and verification evidence fields to open deviation tracking. | QA Supervisor | High | Updated tracker, reviewed open action list. | Supports action management across owners. |

## Immediate Containment
- Hold or verify hold status for open High severity cooling and allergen-related deviations.
- Confirm release decisions for affected batches and units before closure.
- Confirm metal detector reject handling and product disposition since the last good check.

## Corrective Actions
- Review cooling process controls for Line 1 Chilled chicken meal, including load size, tray spacing, equipment performance, and measurement method.
- Review Line 2 label changeover controls, especially old label roll removal and label reconciliation.
- Review Line 3 metal detector setup and maintenance records for Vegetable curry.

## Preventive Actions
- Strengthen checklist completion controls for cooling timestamps, allergen verification, and label changeover.
- Add owner, due date, closure criteria, and verification evidence expectations for open deviations.
- Trend repeated deviations monthly by product, line, process step, and owner.

## Verification Plan
- Verify three consecutive affected-product runs with complete cooling, label, allergen, or metal detector records as applicable.
- Review closure evidence for all currently open High severity records.
- Confirm that repeated deviations decline or are explained in the next monthly trend review.

## Open Risks
- True root causes are not confirmed from the log alone.
- The log does not include batch IDs, measured values, quantities affected, or due dates.
- Open action status may understate risk if closure evidence is missing.

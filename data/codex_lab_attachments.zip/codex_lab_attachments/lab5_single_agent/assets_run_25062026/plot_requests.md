# Plot Requests

## Plot 1

Title: Deviations by Process Step
Data source: `data/food_deviation_log.csv`
Chart type: bar chart
X-axis: process_step
Y-axis: count of deviations
Output file: `assets/plots/deviations_by_process_step.png`
Purpose: Show which process steps have the most recorded deviations.

## Plot 2

Title: Deviations by Deviation Type
Data source: `data/food_deviation_log.csv`
Chart type: bar chart
X-axis: deviation_type
Y-axis: count of deviations
Output file: `assets/plots/deviations_by_deviation_type.png`
Purpose: Show repeated issue types for QA follow-up.

## Plot 3

Title: Open Deviations by Owner
Data source: `data/food_deviation_log.csv`
Chart type: bar chart
X-axis: owner
Y-axis: count of open deviations
Output file: `assets/plots/open_deviations_by_owner.png`
Purpose: Show where open follow-up actions are currently concentrated.

## Plot 4

Title: Deviations by Severity and Status
Data source: `data/food_deviation_log.csv`
Chart type: stacked bar chart
X-axis: severity
Y-axis: count of deviations
Series: status
Output file: `assets/plots/deviations_by_severity_status.png`
Purpose: Show how open and closed deviations are distributed by severity.

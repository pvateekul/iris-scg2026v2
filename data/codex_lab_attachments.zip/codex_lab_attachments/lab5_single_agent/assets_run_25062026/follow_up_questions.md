# Follow-up Questions

## Priority Questions
| Priority | Question | Owner | Why It Matters | Evidence Needed |
|---|---|---|---|---|
| 1 | For each Chilled chicken meal cooling deviation, what were the actual cooling start time, end time, core temperatures, target limits, and final release decision? | QA Supervisor | Confirms containment and whether cooling criteria were met. | Cooling logs, release review, QA disposition. |
| 1 | Were all affected label and allergen records reviewed before product release, and were any units shipped before verification was completed? | QA Supervisor | Confirms label and allergen risk containment. | Release checks, hold records, reconciliation records. |
| 1 | For Line 3 metal detector rejects, were products since the last good check held, inspected, and dispositioned according to SOP? | Maintenance / QA Supervisor | Confirms foreign material control and release status. | Hold records, reject inspection records, challenge test results. |
| 2 | What batch sizes, tray spacing, chiller loading, and room or chiller conditions were present during the repeated cooling delay dates? | Production Supervisor | Tests whether process load or equipment capacity contributed to slower cooling. | Batch records, loading records, chiller temperature trend. |
| 2 | Was probe placement and probe calibration verified for the affected cooling records? | QA Supervisor | Checks whether the issue may involve measurement reliability. | Calibration records, probe placement check, QA review notes. |
| 2 | Was the Line 2 label changeover checklist fully completed, including removal and reconciliation of old label rolls? | Packing Lead | Tests whether line clearance controls contributed to label mix-ups. | Line clearance checklist, label reconciliation. |
| 2 | What changed on Line 3 before the repeated metal detector rejects, including product size adjustment, sensitivity setting, or reject mechanism setup? | Maintenance | Tests equipment and process setting hypotheses. | Maintenance notes, detector settings, product setup record. |
| 3 | Do open records have assigned due dates, closure criteria, and verification evidence requirements? | QA Supervisor | Supports timely closure and prevents repeat open actions. | Deviation tracker, CAPA log, closure evidence list. |

## Questions by Team

### QA
- Can QA confirm final disposition and release decision for all High severity records?
- Are cooling limits, allergen verification requirements, and label release checks clearly recorded in each affected file?
- What verification evidence is required before closing each open deviation?

### Production
- Were batch loading, tray spacing, staffing, or handover conditions different during the Line 1 cooling and allergen-check records?
- Were any production sequence or changeover steps rushed, skipped, or interrupted?

### Maintenance
- Were metal detector calibration, sensitivity, product effect settings, and reject mechanism checks documented for 2026-05-04, 2026-05-07, and 2026-05-12?
- Were any chiller performance checks completed after the repeated cooling delays?

### Supplier / Warehouse
- Is there any evidence of label roll supply, material staging, or storage mix-up contributing to the Tomato sauce label events?
- Were packaging materials segregated and issued against the correct product and date?

## Notes

- These questions are intended to support investigation.
- They should be answered before confirming root cause or final corrective actions.

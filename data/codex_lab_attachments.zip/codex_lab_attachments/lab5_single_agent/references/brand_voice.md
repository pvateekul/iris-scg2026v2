# Brand Voice

## Personality

- Practical quality partner
- Calm process analyst
- Reliable production teammate

## Use

- Concrete process language
- Short paragraphs
- Production examples
- Clear next steps
- Evidence-based wording
- Operational recommendations

## Avoid

- Enterprise jargon
- Overpromising automation
- Fear-based compliance language
- Abstract productivity claims
- Blaming production teams
- Claiming confirmed root cause without evidence

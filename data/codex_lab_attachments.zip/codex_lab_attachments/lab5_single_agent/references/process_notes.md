# Process Notes

## Product Context

This sample project represents a small ready-to-eat food production site.

The site produces chilled ready meals and sauces. Daily QA records are kept in spreadsheets and short notes.

## Process Steps

Common process steps include:

1. Receiving
2. Storage
3. Preparation
4. Cooking
5. Cooling
6. Packing
7. Metal detection
8. Labeling
9. Finished goods storage
10. Dispatch

## Operational Notes

- Cooling performance is important for chilled products.
- Label accuracy is important for allergens and shelf-life control.
- Packing line changes can create mix-up risks if checks are missed.
- Repeated minor deviations should be reviewed because they may indicate process drift.
- Maintenance and calibration records may be needed when equipment-related hypotheses appear.

## Review Principle

The agent should support QA review, not replace site investigation.

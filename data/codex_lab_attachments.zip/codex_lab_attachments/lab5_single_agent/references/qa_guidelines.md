# QA Guidelines

## Review Priorities

When reviewing deviations, prioritize:

1. Food safety risk
2. Legal or label compliance risk
3. Repeated process drift
4. Customer complaint risk
5. Open actions without owner or due date

## Evidence to Look For

Useful evidence includes:

- repeated records across dates
- repeated process step
- repeated line or shift
- severity level
- action taken
- owner
- open or overdue status
- missing measurement or verification data

## Good RCA Practice

- Start with observed facts.
- Separate confirmed evidence from assumptions.
- Do not blame individuals.
- Ask follow-up questions when records are incomplete.
- Do not confirm root cause without enough evidence.
- Link corrective actions to the issue pattern.
- Define evidence needed to close actions.

## Output Tone

Use calm, practical, operational language.
